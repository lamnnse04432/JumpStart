public static PublicKey loadPublicKey(String publicKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
    Decoder decoder = Base64.getDecoder();
    byte[] encoded = decoder.decode(publicKey);

    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
    EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
    return keyFactory.generatePublic(keySpec);
}

public static String rsaEncrypt(String data, String publicKey)
        throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidKeySpecException,
        IllegalBlockSizeException, BadPaddingException {
    Encoder encoder = Base64.getEncoder();
    Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
    cipher.init(Cipher.ENCRYPT_MODE, loadPublicKey(publicKey));
    return encoder.encodeToString(cipher.doFinal(data.getBytes(StandardCharsets.UTF_8)));
}