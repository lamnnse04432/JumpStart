public static PrivateKey loadPrivateKey(String privateKey)
        throws NoSuchAlgorithmException, InvalidKeySpecException {
    Decoder decoder = Base64.getDecoder();
    byte[] encoded = decoder.decode(privateKey);

    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
    return keyFactory.generatePrivate(keySpec);
}

public static String rsaDecrypt(String data, String privateKey)
        throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidKeySpecException,
        IllegalBlockSizeException, BadPaddingException {
    Decoder decoder = Base64.getDecoder();
    Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
    cipher.init(Cipher.DECRYPT_MODE, loadPrivateKey(privateKey));
    return new String(cipher.doFinal(decoder.decode(data)));
}