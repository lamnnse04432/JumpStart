public static boolean verify(String data, String signature, String publicKey)
		throws SignatureException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException,
		NoSuchProviderException, InvalidAlgorithmParameterException {
	Signature sign = Signature.getInstance("RSASSA-PSS");
	Decoder decoder = Base64.getDecoder();

	PSSParameterSpec pssParams = new PSSParameterSpec("SHA-256", "MGF1", new MGF1ParameterSpec("SHA-1"),
			MessageDigest.getInstance("SHA-256").getDigestLength(), PSSParameterSpec.TRAILER_FIELD_BC);
	sign.setParameter(pssParams);

	sign.initVerify(loadPublicKey(publicKey));
	sign.update(data.getBytes(StandardCharsets.UTF_8));
	return sign.verify(decoder.decode(signature));
}