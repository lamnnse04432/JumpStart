public static String sign(String data, String privateKey) throws NoSuchAlgorithmException, InvalidKeyException,
		InvalidKeySpecException, SignatureException, NoSuchProviderException, InvalidAlgorithmParameterException {
	Signature sign = Signature.getInstance("RSASSA-PSS");
	PSSParameterSpec pssParams = new PSSParameterSpec("SHA-256", "MGF1", new MGF1ParameterSpec("SHA-1"),
			MessageDigest.getInstance("SHA-256").getDigestLength(), PSSParameterSpec.TRAILER_FIELD_BC);
	sign.setParameter(pssParams);
	sign.initSign(loadPrivateKey(privateKey));
	sign.update(data.getBytes(StandardCharsets.UTF_8));
	Encoder encoder = Base64.getEncoder();
	return encoder.encodeToString(sign.sign());
}