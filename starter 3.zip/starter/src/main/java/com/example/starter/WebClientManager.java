package com.vps.bgw.common;


import io.vertx.core.Vertx;
import io.vertx.core.http.HttpClientOptions;
import io.vertx.core.net.JksOptions;
import io.vertx.core.net.PemKeyCertOptions;
import io.vertx.ext.web.client.WebClient;
import io.vertx.ext.web.client.WebClientOptions;

import java.util.HashMap;

public class WebClientManager {


  private static WebClientManager instance;
  private final HashMap<String, WebClient> connectionPoolManager = new HashMap<>();

  private WebClientManager() {
  }

  public static synchronized WebClientManager getInstance() {
    if (instance == null) {
      instance = new WebClientManager();
    }

    return instance;
  }

  public synchronized WebClient getWebClient(Vertx vertx, String api) {

    WebClient pool = connectionPoolManager.get(api);
    if (pool == null) {
      WebClientOptions options = new WebClientOptions()

        .setTcpKeepAlive(false)
        .setKeepAlive(true)
        .setKeepAliveTimeout(60)
        .setMaxPoolSize(100)
        .setKeepAliveTimeout(HttpClientOptions.DEFAULT_KEEP_ALIVE_TIMEOUT)
        .setFollowRedirects(false);
      pool = WebClient.create(vertx, options);
      connectionPoolManager.put(api, pool);
    }

    return pool;
  }

}
