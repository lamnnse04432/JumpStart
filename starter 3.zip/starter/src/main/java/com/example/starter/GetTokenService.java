package com.example.starter;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.vps.bgw.common.WebClientManager;

import io.vertx.core.Future;
import io.vertx.core.Promise;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.client.WebClient;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class GetTokenService {

  private static final Logger LOG = LoggerFactory.getLogger(GetTokenService.class);

  private ObjectMapper objectMapper = new ObjectMapper();
  private final WebClient webClient;
  private final Vertx vertx;
  private static GetTokenService instance;

  private static final String KEY = "TOKEN_TCB" ;

  private static final String TEXT_LOGIN = "{} | LOGIN | {}";


  private final RedissonClient redisson;

  protected GetTokenService(Vertx vertx) {
    this.vertx = vertx;
    this.webClient = WebClientManager.getInstance().getWebClient(vertx, "LOGIN");
    this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    this.redisson = RedissonProvider.getInstance().getRedissonClient();
  }

  public static synchronized GetTokenService getInstance(Vertx vertx) {
    if (instance == null) {
      instance = new GetTokenService(vertx);
    }
    return instance;
  }

  protected void handleRequest(String id, Promise<TokenInfoResp> promise, RLock lock) {
    StopWatch watch = new StopWatch();
    watch.start();
    this.webClient.getAbs("http://127.0.0.1:8080/login")
      .timeout(60000)
      .putHeader("Content-Type", "application/json")
      .sendJsonObject(null)
      .onSuccess(response -> {
        watch.stop();
        LOG.info("{} | LOGIN | Time response: : {} ms", id, TimeUnit.MILLISECONDS.convert(watch.getNanoTime(), TimeUnit.NANOSECONDS));
        try {
          LOG.info("{} | LOGIN | Header TCB Login response : {} | {}", id, response.statusCode(), StringUtils.isEmpty(response.statusMessage()) ? "" : response.statusMessage());
          if (response.statusCode() == 200) {
            String bodyAsString = response.bodyAsString();
            LOG.info("{} | LOGIN | Data TCB Login response : {}", id, bodyAsString);

            TokenInfoResp tokenInfoResp = this.objectMapper.readValue(bodyAsString, TokenInfoResp.class);

            this.saveTokenRedis(id, tokenInfoResp);

            LOG.info("{} | LOGIN | ======================== TCB Login RESPONSE SUCCESS =======================================", id);
            this.unlockRedis(id, lock);
            promise.tryComplete(tokenInfoResp);
          } else {
            LOG.info("{} | LOGIN | TCB Login RESPONSE ERROR: {}", id, response.statusMessage());
            this.unlockRedis(id, lock);
            promise.tryFail(response.statusMessage());
          }
        } catch (Exception e) {
          LOG.error(TEXT_LOGIN, id, e.getMessage(), e);
          this.unlockRedis(id, lock);
          promise.tryFail(e.getMessage());
        }
      }).onFailure(throwable -> {
        LOG.error(TEXT_LOGIN, id, throwable.getMessage(), throwable);
        this.unlockRedis(id, lock);
        promise.tryFail(throwable.getMessage());
      });


  }

  private void unlockRedis(String id, RLock lock) {
    lock.unlock();
    LOG.info("{} | LOGIN | Unlock Success", id);
  }


  public synchronized Future<TokenInfoResp> handle(String id, Promise<TokenInfoResp>... promises) {
    Promise<TokenInfoResp> promise = promises.length > 0 ? promises[0] : Promise.promise();

    if (this.checkExpire()) {
      LOG.info("{} | LOGIN | ======================================== Token is active ========================================", id);
      TokenInfoResp tokenInfoResp = this.getTokenRedis(id);

      promise.tryComplete(tokenInfoResp);
    } else {
      LOG.info("{} | LOGIN | ======================================== Token is expired ========================================", id);
      LOG.info("{} | LOGIN | {} - {}", id,Thread.currentThread().getId(),Thread.currentThread().getName());
      RLock lock = redisson.getLock("LOCK_TCB");
      try {
        boolean isLocked = lock.tryLock();
        if (isLocked) {
          LOG.info("{} | LOGIN | Lock Success", id);
          this.handleRequest(id, promise, lock);

        } else {
          LOG.info("{} | LOGIN | Lock Fail", id);
          this.vertx.setTimer(1000, idTimer -> {
            LOG.info("{} | LOGIN | Run timer", id);
            this.vertx.cancelTimer(idTimer);
            this.handle(id, promise);
          });
        }
      } catch (Exception e) {
        this.unlockRedis(id, lock);
        LOG.error(TEXT_LOGIN, id, e.getMessage(), e);
        promise.tryFail(e.getMessage());
      }
    }
    return promise.future();
  }

  private void saveTokenRedis(String id, TokenInfoResp tokenInfoResp) {
    long dateNow = new Date().getTime() / 1000;
    long expireDate = Long.parseLong(tokenInfoResp.getExpireAt());
    LOG.info("{} | LOGIN | Date Now : {}", id, dateNow);
    LOG.info("{} | LOGIN |  Expire Date : {}", id, expireDate);
    long ttlToken = expireDate - dateNow;
    LOG.info("{} | LOGIN | ttlToken : {}", id, ttlToken);
    redisson.getBucket(KEY).set(JsonObject.mapFrom(tokenInfoResp).toString(), ttlToken, TimeUnit.SECONDS);
  }

  private TokenInfoResp getTokenRedis(String id) {
    String data = redisson.getBucket(KEY).get().toString();
    LOG.info("{} | LOGIN | getTokenRedis : {}", id, data);
    try {
      return this.objectMapper.readValue(data, new TypeReference<TokenInfoResp>() {
      });
    } catch (Exception e) {
      LOG.error("{} | LOGIN | Error convert object : {}", id, e.getMessage(), e);
      return null;
    }
  }

  private boolean checkExpire() {
    return redisson.getBucket(KEY).isExists();
  }


//    private boolean checkExpired(String id, TokenInfoResp tokenInfoResp) {
//        long dateNow = new Date().getTime() / 1000;
//        long expireDate = Long.parseLong(tokenInfoResp.getExpireAt());
//        LOG.info("{} | LOGIN | Date Now : {}", id, dateNow);
//        LOG.info("{} | LOGIN | Date Expire Date : {}", id, expireDate);
//        return dateNow > expireDate;
//    }

//    private void saveTokenRedis(String id, TokenInfoResp tokenInfoResp) {
//        List<String> tokenRedis = Arrays.asList(KEY, JsonObject.mapFrom(tokenInfoResp).toString());
//        List<String> expireRedis = Arrays.asList(KEY, tokenInfoResp.getExpireAt());
//        //     this.redisProvider.redis().onSuccess(redisAPI -> {
//        this.redisAPI.setex(KEY, JsonObject.mapFrom(tokenInfoResp).toString(), tokenInfoResp.getExpireAt()).onSuccess(cmd -> {
//            LOG.info("{} | LOGIN | Save token success", id);
//        }).onFailure(cmd -> {
//            LOG.info("{} | LOGIN | Save token fail : {}", id, cmd.getMessage());
//        });
//        //   });
  //   }

//    private TokenInfoResp getTokenRedis(String id) throws JsonProcessingException {
//        //    this.redisProvider.redis().onSuccess(redisAPI -> {
//        String data = redisAPI.get(KEY).result().toString();
//        //   });
//
//        LOG.info("{} | LOGIN | getTokenRedis : {}", id, data);
//        TokenInfoResp tokenInfo = this.objectMapper.readValue(data, new TypeReference<TokenInfoResp>() {
//        });
//        return tokenInfo;
//    }

//    private boolean checkExpire(String id) {
//        return redisAPI.exists(Arrays.asList(KEY)).result().equals("1");
//    }

  //    public synchronized Future<TokenInfoResp> handle(String id, Promise<TokenInfoResp>... promises) throws Exception {
//        Promise<TokenInfoResp> promise = promises.length > 0 ? promises[0] : Promise.promise();
//
//        if (this.checkExpire(id)) {
//            LOG.info("{} | LOGIN | ======================================== Token is active ========================================", id);
//            TokenInfoResp tokenInfoResp = this.getTokenRedis(id);
//            promise.tryComplete(tokenInfoResp);
//        } else {
//            LOG.info("{} | LOGIN | ======================================== Token is expired ========================================", id);
//            this.handleRequest(id, promise);
//        }
//        return promise.future();
//    }


}
