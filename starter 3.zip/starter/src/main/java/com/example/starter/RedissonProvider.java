package com.example.starter;


import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RedissonProvider extends AbstractVerticle {
  private static final Logger LOG = LoggerFactory.getLogger(RedissonProvider.class);

  private static RedissonProvider instance;

  private static RedissonClient redissonClient;

  public static synchronized RedissonProvider getInstance() {
    if (instance == null) {
      instance = new RedissonProvider();
    }
    return instance;
  }

  public RedissonClient getRedissonClient() {
    return redissonClient;
  }

  @Override
  public void start(Promise<Void> startPromise) {
    this.configRedisson(startPromise);
  }

  private void configRedisson(Promise<Void> startPromise) {
    try {
      Config config = new Config();
      config.useSingleServer()
        .setAddress("redis://127.0.0.1:6379")
        .setConnectionPoolSize(100)
        .setConnectTimeout(6000);
      this.redissonClient = Redisson.create(config);
      startPromise.tryComplete();
    } catch (Exception e) {
      LOG.error(e.toString(), e);
      startPromise.tryFail(e);
    }
  }
}
