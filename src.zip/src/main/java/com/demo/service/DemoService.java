package com.demo.service;

import com.demo.model.TestEntity;
import com.demo.repo.DemoRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DemoService {

    @Autowired
    private DemoRepo repo;

    public List<TestEntity> getAll() {
        return repo.findAll();
    }

}
