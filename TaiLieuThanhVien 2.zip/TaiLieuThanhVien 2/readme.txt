File Postman collection: BPS-pentest.postman_collection.json 
File Automation Test trên Jmeter: Plan Member Test.jmx
File ToolGenDataTest.rar: code demo mã hóa bản tin
