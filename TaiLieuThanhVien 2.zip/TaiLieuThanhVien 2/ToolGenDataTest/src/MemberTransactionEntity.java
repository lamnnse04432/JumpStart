import java.text.MessageFormat;

public class MemberTransactionEntity {

	public String bicCode;

	public String transactionNo;

	public int transactionType;

	public long transactionDate;

	public String signature;

	public String data;

	public String signRawData(String signData) {
		return MessageFormat.format("{0}|{1}|{2}|{3}|{4}", this.bicCode, this.transactionNo,
				this.transactionType, MessageEncryptUtil.number2String(this.transactionDate, "#.#"), signData);
	}
}
