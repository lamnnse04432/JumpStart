import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.EncodedKeySpec;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.PSSParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.text.DecimalFormat;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public interface MessageEncryptUtil {
	
	public static String number2String(double val, String format) {
		DecimalFormat decFormat = new DecimalFormat(format);
		return decFormat.format(val);
	}

	public static String rsaEncrypt(String data, String publicKey) throws Exception {
		Decoder decoder = Base64.getDecoder();
		Encoder encoder = Base64.getEncoder();
		
		byte[] encoded = decoder.decode(publicKey);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);		
		PublicKey pubKey = keyFactory.generatePublic(keySpec);
				
		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");		
		cipher.init(Cipher.ENCRYPT_MODE, pubKey);
		return encoder.encodeToString(cipher.doFinal(data.getBytes(StandardCharsets.UTF_8)));
	}

	public static String sign(String data, String privateKey) throws Exception  {
		Decoder decoder = Base64.getDecoder();
		byte[] encoded = decoder.decode(privateKey);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
		PrivateKey pKey = keyFactory.generatePrivate(keySpec);
		
		Signature sign = Signature.getInstance("RSASSA-PSS");
		PSSParameterSpec pssParams = new PSSParameterSpec("SHA-256", "MGF1", new MGF1ParameterSpec("SHA-1"),
				MessageDigest.getInstance("SHA-256").getDigestLength(), PSSParameterSpec.TRAILER_FIELD_BC);
		sign.setParameter(pssParams);
		sign.initSign(pKey);
		sign.update(data.getBytes(StandardCharsets.UTF_8));
		Encoder encoder = Base64.getEncoder();
		return encoder.encodeToString(sign.sign());
	}

	public static String encrypt(String data, String password) throws Exception  {
		byte[] decodedKey = Base64.getDecoder().decode(password);	
		SecretKeySpec secretKeySpec = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
		byte[] byteEncrypted = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
		return Base64.getEncoder().encodeToString(byteEncrypted);
	}
}
