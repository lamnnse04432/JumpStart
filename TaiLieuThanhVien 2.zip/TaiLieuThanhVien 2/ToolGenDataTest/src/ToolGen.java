import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ToolGen {
	private static Long total = 0L;
	private static String member = "";
	private static String privateKey = "";
	private static String account = "";
	private static String session = "";
	private static String biccode = "";
	private static final String SAMPLE_CSV_FILE = "./sample.csv";
	
	public static void main(String[] args) {
		System.out.println("Test");
		Properties prop = new Properties();
	    String fileName = "config.properties";
	    InputStream is;
		try {
			is = new FileInputStream(fileName);
			prop.load(is);
			ObjectMapper mapper = new ObjectMapper();
			BufferedWriter writer = Files.newBufferedWriter(Paths.get(SAMPLE_CSV_FILE));
			CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("token", "member", "raw"));
			
			total = Long.parseLong(prop.getProperty("total"));
			member = prop.getProperty("member");
			privateKey = prop.getProperty("private");
			account = prop.getProperty("account");
			session = prop.getProperty("session");
			biccode = prop.getProperty("biccode");
			String
			 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhYiherKDTYleSG4+2oC5nLsBYYye6iJi/Qn3pNkDoWeBggq5w+l13MxVCkJUALPIV9bO0nqiJWLUIVdq8nffU6doaeLKC4lbhX9SYEq2n6ZyTpaFHm4IpGngZTtrkQ6QSc7HKOKnMJ+80jwoewE4GHR2WB8Z8jp0rHlWGFSGncvVzFFiqLblHm2GxQsYmWVEprY1HJnLdnch975oS/ZWYhLmz/3PRUBSyImieo3yrWUGvs+AwS+/FuBHA4+HiPHbftEdwL+sE1MdzUwIb6wHPvBnEaeyrJwzAxiWOiHHy07aVIOIrgTQ41k2YPK2nrT84GjvLqOTxlkJ4y024JaurQIDAQAB";
			String token = MessageEncryptUtil.rsaEncrypt(session, vcbPublicKey);
			Random rn= new Random();
			Long transDate = new Date().getTime() / 1000;
			for(Long i=0L; i<total; i++) {
				DetailTransactionEntity trans = new DetailTransactionEntity();
				trans.accountNo = account;
				trans.currency = "VND";
				trans.description = "Auto test";
				trans.amount =  (double)(rn.nextInt(5000) +1);
				
				String enc = MessageEncryptUtil.encrypt(mapper.writeValueAsString(trans), session);
				MemberTransactionEntity request = new MemberTransactionEntity();
				request.bicCode = biccode;
				request.transactionDate = transDate;
				request.data = enc;
				request.transactionType = 900;
				request.transactionNo = "TOOL-" + transDate.toString() +String.valueOf(i) + String.valueOf(rn.nextInt(5000) + 1);
				request.signature = MessageEncryptUtil.sign(request.signRawData(trans.signRawData()), privateKey);
				
				String content = mapper.writeValueAsString(request);
				csvPrinter.printRecord(token, member, content);
			}
			csvPrinter.flush();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
