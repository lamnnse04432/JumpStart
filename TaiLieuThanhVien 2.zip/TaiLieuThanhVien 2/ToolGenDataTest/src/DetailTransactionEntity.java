import java.text.MessageFormat;

public class DetailTransactionEntity {
	public String accountNo;
	public String currency;
	public double amount;
	public String description;

	public String signRawData() {
		return MessageFormat.format("{0}|{1}|{2}", this.accountNo, this.currency, MessageEncryptUtil.number2String(this.amount, "#.#"));
	}
}
