package com.example.starter;

import io.vertx.core.DeploymentOptions;
import io.vertx.core.Vertx;

public class Application {

  public static void main(String[] args) {
    Vertx vertx = Vertx.vertx();
    vertx.deployVerticle(MainVerticle.class.getName(), new DeploymentOptions().setInstances(1));
   // vertx.deployVerticle(Consumer.class.getName(), new DeploymentOptions().setInstances(1));

   // vertx.deployVerticle(RedisVerticle.class.getName(), new DeploymentOptions().setInstances(1));

    System.out.println("+++++++++++++++");
  }
}
