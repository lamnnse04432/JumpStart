package com.example.starter;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import io.vertx.kafka.client.producer.KafkaProducer;
import io.vertx.kafka.client.producer.KafkaProducerRecord;
import io.vertx.kafka.client.serialization.JsonObjectSerializer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class Producer implements Handler<RoutingContext> {

  private static final Logger LOGGER = LoggerFactory.getLogger(Producer.class);
  private Vertx vertx;

  public Producer(Vertx vertx) {
    this.vertx = vertx;
  }

  @Override
  public void handle(RoutingContext rc) {
    JsonObject data = rc.getBodyAsJson();

    Properties config = new Properties();
    config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9093");
    config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonObjectSerializer.class);
    config.put(ProducerConfig.ACKS_CONFIG, "1");

    KafkaProducer<String, JsonObject> producer = KafkaProducer.create(vertx, config);

   // String o = Json.decodeValue(rc.getBodyAsString(), String.class);
    KafkaProducerRecord<String,
      JsonObject> record = KafkaProducerRecord.create("test-topic", rc.getBodyAsJson());
    producer.write(record, done -> {
      if (done.succeeded()) {
     //   RecordMetadata recordMetadata = done.result();
        LOGGER.info("Record sent: msg={}, destination={}, partition={}, offset={}", record.value());
//          recordMetadata.getTopic(),
//          recordMetadata.getPartition(),
//          recordMetadata.getOffset());

      } else {
        Throwable t = done.cause();
        LOGGER.error("Error sent to topic: {}", t.getMessage());

      }
      rc.response().end("ok");
    });

  }




}
