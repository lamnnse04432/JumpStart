package com.example.starter;

import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import io.vertx.redis.client.RedisAPI;
import io.vertx.redis.client.RedisConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.swisspush.redisques.util.DefaultRedisProvider;

import java.util.Arrays;

public class TestHandle implements Handler<RoutingContext> {

  private static final Logger LOGGER = LoggerFactory.getLogger(Producer.class);
  private Vertx vertx;

  private RedisConnection redis;

 // private final RedisProvider redisProvider;



  private final   RedisAPI redisAPI;

  public TestHandle(Vertx vertx) {
    this.vertx = vertx;
      this.redisAPI = new DefaultRedisProvider(this.vertx).redis().result();
  //  redisAPI =  redisProvider.redis().result();
  }

  @Override
  public void handle(RoutingContext rc) {
//    redis   = RedisVerticle.client;
//   RedisAPI redisAPI = RedisVerticle.redisAPI;



      this.redisAPI.set(Arrays.asList("II","20"), r -> {
        System.out.println(">>>>> r "+r.succeeded());

    });



    this.redisAPI.set(Arrays.asList("HH","20"), r -> {
        System.out.println(">>>>> r "+r.succeeded());

    });



    rc.response().end("ok");

    JsonObject data = rc.getBodyAsJson();

//    this.redis.send(Request.cmd(Command.SET).arg("TOKEN").arg(rc.getBodyAsString())).onSuccess(x -> {
//      this.redis.send(Request.cmd(Command.EXPIRE).arg("BB").arg(10)).onSuccess( z -> {
//        System.out.println(">>>>>>>EXPIRE:"+ z.toString());
//        this.redis.send(Request.cmd(Command.TTL).arg("BB")).onSuccess( e -> {
//          System.out.println(">>>>>>>TTL:"+ e.toString());
//        });
//      });
//
//      rc.response().end("ok");
//    }).onFailure(y -> {
//      System.out.println(y.getMessage());
//      rc.response().end("fail");
//    });




  }
}
