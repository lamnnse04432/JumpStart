package org.swisspush.redisques.util;

import com.example.starter.RedisProvider;
import com.example.starter.RedisVerticle;
import io.vertx.core.Future;
import io.vertx.core.Promise;
import io.vertx.core.Vertx;
import io.vertx.redis.client.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Default implementation for a Provider for {@link RedisAPI}
 *
 * @author https://github.com/mcweba [Marc-Andre Weber]
 */
public class DefaultRedisProvider implements RedisProvider {

  private static final Logger log = LoggerFactory.getLogger(DefaultRedisProvider.class);
  private static final int MAX_RECONNECT_RETRIES = 16;
  private static RedisVerticle instance;
  private final Vertx vertx;
  private final AtomicBoolean CONNECTING = new AtomicBoolean();
  private final AtomicBoolean connecting = new AtomicBoolean();
  private final AtomicReference<Promise<RedisAPI>> connectPromiseRef = new AtomicReference<>();
  private RedisAPI redisAPI;
  private Redis redis;
  private RedisConnection client;

  public DefaultRedisProvider(Vertx vertx) {
    this.vertx = vertx;

  }


  public Future<RedisAPI> redis() {
    if (redisAPI != null) {
      return Future.succeededFuture(redisAPI);
    } else {
      return setupRedisClient();
    }
  }

  public Future<Redis> connection() {
    if (redis != null) {
      return Future.succeededFuture(redis);
    } else {
      return setupRedisClient().compose(redisAPI -> Future.succeededFuture(redis));
    }
  }


  private Future<RedisAPI> setupRedisClient() {
    System.out.println("chay vao setup");
    Promise<RedisAPI> currentPromise = Promise.promise();
    Promise<RedisAPI> masterPromise = connectPromiseRef.accumulateAndGet(
      currentPromise, (oldVal, newVal) -> (oldVal != null) ? oldVal : newVal);
    if (currentPromise == masterPromise) {
      // Our promise is THE promise. So WE have to resolve it.
      connectToRedis().onComplete(event -> {
        connectPromiseRef.getAndSet(null);
        if (event.failed()) {
          currentPromise.fail(new Exception(event.cause()));
        } else {
          redisAPI = event.result();
          currentPromise.complete(redisAPI);
        }
      });
    }

    // Always return master promise (even if we didn't create it ourselves)
    return masterPromise.future();
  }

  private Future<RedisAPI> connectToRedis() {

    int redisMaxPoolSize = 8;
    int redisMaxPoolWaitingSize = 8;
    int redisMaxPipelineWaitingSize = 32;
    int redisPoolRecycleTimeoutMs = 60;

    Promise<RedisAPI> promise = Promise.promise();

    // make sure to invalidate old connection if present
    if (redis != null) {
      redis.close();
    }

    if (connecting.compareAndSet(false, true)) {
      RedisOptions redisOptions = new RedisOptions()
        .addConnectionString("redis://127.0.0.1:6379")
        .setMaxPoolSize(redisMaxPoolSize)
        .setMaxPoolWaiting(redisMaxPoolWaitingSize)
        .setPoolRecycleTimeout(redisPoolRecycleTimeoutMs)
        .setMaxWaitingHandlers(redisMaxPipelineWaitingSize)
        .setType(RedisClientType.STANDALONE);


      redis = Redis.createClient(vertx, redisOptions);

      redis.connect().onSuccess(conn -> {
        log.info("Successfully connected to redis");
        client = conn;

//                if (config.getRedisClientType() == RedisClientType.STANDALONE) {
//                    client.close();
//                }

        // make sure the client is reconnected on error
        // eg, the underlying TCP connection is closed but the client side doesn't know it yet
        //     the client tries to use the staled connection to talk to server. An exceptions will be raised
        conn.exceptionHandler(e -> {
          attemptReconnect(0);
        });

        // make sure the client is reconnected on connection close
        // eg, the underlying TCP connection is closed with normal 4-Way-Handshake
        //     this handler will be notified instantly
        conn.endHandler(placeHolder -> {
          attemptReconnect(0);
        });

        // allow further processing
        redisAPI = RedisAPI.api(conn);
        promise.complete(redisAPI);
        connecting.set(false);
      }).onFailure(t -> {
        promise.fail(t);
        connecting.set(false);
      });
    } else {
      promise.complete(redisAPI);
    }

    return promise.future();
  }


  private void attemptReconnect(int retry) {
    if (retry > MAX_RECONNECT_RETRIES) {
      // we should stop now, as there's nothing we can do.
      CONNECTING.set(false);
    } else {
      // retry with backoff up to 10240 ms
      long backoff = (long) (Math.pow(2, Math.min(retry, 10)) * 10);

      vertx.setTimer(backoff, timer -> {
        setupRedisClient()
          .onFailure(t -> attemptReconnect(retry + 1));
      });
    }
  }
}
