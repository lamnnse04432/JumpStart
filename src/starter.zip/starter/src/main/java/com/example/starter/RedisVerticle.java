package com.example.starter;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Promise;
import io.vertx.redis.client.*;

import java.util.concurrent.atomic.AtomicBoolean;

public class RedisVerticle extends AbstractVerticle {
  private static final int MAX_RECONNECT_RETRIES = 16;
  private static RedisVerticle instance;

  private final AtomicBoolean CONNECTING = new AtomicBoolean();
  private Redis redis;
  public static RedisConnection client;

  public static RedisAPI redisAPI;


  @Override
  public void start() {
    System.out.println("run");

 createRedisClient().onSuccess(conn -> {
      // connected to redis!
      System.out.println("connected to redis!");
    }).result();
    System.out.println("run");
  }





  /**
   * Will create a redis client and setup a reconnect handler when there is
   * an exception in the connection.
   */
  private Future<RedisConnection> createRedisClient() {
    RedisOptions options = new RedisOptions();
    options.addConnectionString("redis://127.0.0.1:6379")
      .setMaxPoolSize(10)
      .setType(RedisClientType.STANDALONE);

    Promise<RedisConnection> promise = Promise.promise();

    // make sure to invalidate old connection if present
    if (redis != null) {
      redis.close();
    }

    if (CONNECTING.compareAndSet(false, true)) {
      try {
        redis = Redis.createClient(vertx, options);
        redis
          .connect()
          .onSuccess(conn -> {
            client = conn;

            // make sure the client is reconnected on error
            // eg, the underlying TCP connection is closed but the client side doesn't know it yet
            //     the client tries to use the staled connection to talk to server. An exceptions will be raised
            conn.exceptionHandler(e -> {
              attemptReconnect(0);
            });

            // make sure the client is reconnected on connection close
            // eg, the underlying TCP connection is closed with normal 4-Way-Handshake
            //     this handler will be notified instantly
            conn.endHandler(placeHolder -> {
              attemptReconnect(0);
            });

            // allow further processing
            this.redisAPI = RedisAPI.api(conn);
            promise.complete(conn);
            CONNECTING.set(false);
          }).onFailure(t -> {
            promise.fail(t);
            CONNECTING.set(false);
          });
      } catch (Exception e) {
        System.out.println(">>>>>>> " + e.toString());
      }
    } else {
      promise.complete();
    }
    return promise.future();
  }

  /**
   * Attempt to reconnect up to MAX_RECONNECT_RETRIES
   */
  private void attemptReconnect(int retry) {
    if (retry > MAX_RECONNECT_RETRIES) {
      // we should stop now, as there's nothing we can do.
      CONNECTING.set(false);
    } else {
      // retry with backoff up to 10240 ms
      long backoff = (long) (Math.pow(2, Math.min(retry, 10)) * 10);

      vertx.setTimer(backoff, timer -> {
        createRedisClient()
          .onFailure(t -> attemptReconnect(retry + 1));
      });
    }
  }
}

