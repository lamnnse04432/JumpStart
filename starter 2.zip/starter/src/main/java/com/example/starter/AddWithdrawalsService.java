package com.example.starter;


import com.fasterxml.jackson.core.type.TypeReference;
import io.vertx.core.MultiMap;
import io.vertx.core.Vertx;

import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;



public class AddWithdrawalsService extends com.vps.bgw.rest.handler.AbstractHandler {

  public AddWithdrawalsService(Vertx vertx) {
    super(vertx);
  }

  @Override
  protected void handleRequest(RoutingContext routingContext) {

    String uniqueId = StringUtils.uniqueMessageId();

    try {

      JsonObject request = routingContext.getBodyAsJson();
      LOG.info("{} | {} | Received a CBG request: {}", uniqueId, getApiName(), request);
      DtoRequest requestData = this.objectMapper.readValue(request.toString(),
        new TypeReference<DtoRequest>() {
        });




      MultiMap headerReqBank = MultiMap.caseInsensitiveMultiMap();
      headerReqBank.add("Content-Type", "application/json");

            this.getToken.handle(uniqueId).onComplete(auth -> {
              if (auth.succeeded()) {


                this.sendResponse(routingContext, JsonObject.mapFrom(requestData), uniqueId);

              } else {
                LOG.error("{} | TCB response : {} ", uniqueId, auth.cause().getMessage());

                this.sendResponse(routingContext, JsonObject.mapFrom(requestData), uniqueId);

              }

            });



    } catch (Exception e) {
      LOG.error("{} | " + e.getMessage(), uniqueId, e);

      this.sendResponse(routingContext,JsonObject.mapFrom(null), uniqueId);
    }
  }



  @Override
  protected String getApiName() {
    return "ADD-WITHDRAWLS";
  }



}
