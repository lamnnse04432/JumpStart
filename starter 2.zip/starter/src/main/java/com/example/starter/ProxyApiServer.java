package com.example.starter;


import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.http.*;
import io.vertx.core.net.PfxOptions;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.BodyHandler;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ProxyApiServer extends AbstractVerticle {


  @Override
  public void start(Promise<Void> startPromise) {
    Router router = Router.router(vertx);

    router.route().handler(BodyHandler.create());
    router.route("/").handler(routingContext -> {
      HttpServerResponse response = routingContext.response();
      response.putHeader(HttpHeaders.CONTENT_TYPE, "text/plain")
        .end("Application is running. Startup time: "
          + new SimpleDateFormat("yyyy-MM-dd HH🇲🇲ss").format(new Date(Application.STARTUP_TIME)));
    });

    addRoute(router);

    vertx.createHttpServer()
      .requestHandler(router)
      .listen(getPort(), result -> {
        if (result.succeeded()) {
          startPromise.complete();
        } else {
          startPromise.fail(result.cause());
        }
      });
  }

  private void addRoute(Router router) {
    router.route(HttpMethod.POST, "/test").handler(new AddWithdrawalsService(vertx));
  }

  private int getPort() {
    return 8181;
  }
}
