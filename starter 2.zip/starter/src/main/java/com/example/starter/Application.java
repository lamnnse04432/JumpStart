package com.example.starter;

import io.vertx.core.DeploymentOptions;
import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.core.json.JsonObject;
import io.vertx.micrometer.MicrometerMetricsOptions;
import io.vertx.micrometer.VertxPrometheusOptions;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.Security;

public class Application {

  private static final Logger LOG = LoggerFactory.getLogger(Application.class);

  public static final long STARTUP_TIME = System.currentTimeMillis();

  public static void main(String[] args) {

    Security.addProvider(new BouncyCastleProvider());
    int scaleFactor = Runtime.getRuntime().availableProcessors() * 2;
    LOG.info(">>>>>>>>>>>>> Scale Factor : {}", scaleFactor);
    VertxOptions vertxOptions = new VertxOptions()
      .setEventLoopPoolSize(scaleFactor)
      //   .setWorkerPoolSize(scaleFactor)
      .setMetricsOptions(
        new MicrometerMetricsOptions()
          .setPrometheusOptions(
            new VertxPrometheusOptions()
              .setEnabled(true)
              .setPublishQuantiles(true)
          )
          .setJvmMetricsEnabled(true)
          .setEnabled(true)
      );
    Vertx vertx = Vertx.vertx(vertxOptions);

    startRedisAndHsmManager(vertx).onSuccess(asyncResult -> {
        startProxyApiServer(vertx, scaleFactor);

      }).onFailure(f -> {
        LOG.error("Unable to start application, please check redis");
        vertx.close();
      });

    registerShutdownHook(vertx);
  }

  private static void registerShutdownHook(Vertx vertx) {
    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
      LOG.info("-----------------------------------");
      LOG.info("----------- SHUTDOWN --------------");
      LOG.info("-----------------------------------");
      vertx.close().onComplete(element -> LOG.info("----------- DONE --------------"));
    }));
  }


  private static Future<String> startRedisAndHsmManager(Vertx vertx) {

    DeploymentOptions deploymentOptions = new DeploymentOptions()
      .setInstances(1)
      .setWorker(true);
    return vertx.deployVerticle(RedissonProvider.class.getName(), deploymentOptions);
  }



  private static void startProxyApiServer(Vertx vertx, int scaleFactor) {

    DeploymentOptions deploymentOptions = new DeploymentOptions()
      .setInstances(scaleFactor);

    vertx.deployVerticle(ProxyApiServer.class.getName(), deploymentOptions).onComplete(result -> {
      if (result.succeeded()) {
        LOG.info("Proxy API server started on port {}", 8181);
      } else {
        LOG.error("Unable to start Proxy API server", result.cause());
      }
    });
  }

}
