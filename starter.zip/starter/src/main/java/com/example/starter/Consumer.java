package com.example.starter;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.json.Json;
import io.vertx.kafka.client.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class Consumer extends AbstractVerticle {
  private static final Logger LOGGER = LoggerFactory.getLogger(Consumer.class);

  public void start(Promise<Void> startPromise) {
    Properties config = new Properties();
    config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9093");
    config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
    config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
    config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
   config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
    config.put("group.id", "1");
    KafkaConsumer<String, String> consumer = KafkaConsumer.create(vertx, config);

    consumer.subscribe("test-topic", ar -> {
      if (ar.succeeded()) {
        System.out.println("Subscribed");

      } else {
        System.out.println("Could not subscribe: err={}"+ ar.cause().getMessage());
      }
    });

    consumer.handler(record -> {
      System.out.println("Processing: key={}, value={}, partition={}, offset={}"+ record.key() + " - "+ record.value() +" - "+ record.partition() +" - "+ record.offset());
     //String order = Json.decodeValue(record.value(), String.class);
      throw new RuntimeException("Error");
    //    System.out.println("Order processed: id={}, price={}"+ record.value());
    });
  }
}
